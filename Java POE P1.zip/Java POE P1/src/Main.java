import java.util.Scanner;
import java.util.regex.Pattern;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Login login = new Login();

        System.out.println("=========================================");
        System.out.println("        REGISTRATION SYSTEM              ");
        System.out.println("=========================================\n");

        // ---------- REGISTRATION ----------
        System.out.print("Enter First Name: ");
        String firstName = scanner.nextLine();

        System.out.print("Enter Last Name: ");
        String lastName = scanner.nextLine();

        System.out.print("Enter Username (must contain '_' and be longer than 5 characters): ");
        String username = scanner.nextLine();

        System.out.print("Enter Password (min 8 characters, 1 capital, 1 number, 1 special): ");
        String password = scanner.nextLine();

        System.out.print("Enter Cell Phone (e.g. +27838968976): ");
        String cellPhone = scanner.nextLine();

        // Attempt registration
        String registrationMessage = login.registerUser(username, password, cellPhone, firstName, lastName);
        System.out.println("\n--- Registration Result ---");
        System.out.println(registrationMessage);

        // Only proceed to login if registration was successful
        if (registrationMessage.startsWith("Username successfully")) {
            
            System.out.println("\n=========================================");
            System.out.println("              LOGIN                      ");
            System.out.println("=========================================\n");

            System.out.print("Enter Username: ");
            String loginUsername = scanner.nextLine();

            System.out.print("Enter Password: ");
            String loginPassword = scanner.nextLine();

            boolean isLoggedIn = login.loginUser(loginUsername, loginPassword);
            System.out.println("\n--- Login Result ---");
            System.out.println(login.returnLoginStatus(isLoggedIn));
        } else {
            System.out.println("\nPlease fix the errors above and try registering again.");
        }

        scanner.close();
    }
}

/**
 * The Login class containing all the registration and login methods.
 */
class Login {

    private String storedUsername;
    private String storedPassword;
    private String storedCellPhone;
    private String storedFirstName;
    private String storedLastName;

    public boolean checkUserName(String username) {
        if (username == null) return false;
        return username.contains("_") && username.length() <= 5;
    }

    public boolean checkPasswordComplexity(String password) {
        if (password == null) return false;
        String regex = "^(?=.*[A-Z])(?=.*\\d)(?=.*[^a-zA-Z0-9]).{8,}$";
        return Pattern.matches(regex, password);
    }

    public boolean checkCellPhoneNumber(String phone) {
        if (phone == null) return false;
        String regex = "^\\+27[0-9]{9}$";
        return Pattern.matches(regex, phone);
    }

    public String registerUser(String username, String password, String cellPhone, String firstName, String lastName) {
        if (!checkUserName(username)) {
            return "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.";
        }
        if (!checkPasswordComplexity(password)) {
            return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }
        if (!checkCellPhoneNumber(cellPhone)) {
            return "Cell number is incorrectly formatted or does not contain an international code; please correct the number and try again.";
        }

        this.storedUsername = username;
        this.storedPassword = password;
        this.storedCellPhone = cellPhone;
        this.storedFirstName = firstName;
        this.storedLastName = lastName;

        return "Username successfully captured.\nPassword successfully captured.\nCell number successfully added.";
    }

    public boolean loginUser(String username, String password) {
        return username != null && password != null
                && username.equals(this.storedUsername)
                && password.equals(this.storedPassword);
    }

    public String returnLoginStatus(boolean isLoggedIn) {
        if (isLoggedIn) {
            return "Welcome " + this.storedFirstName + ", " + this.storedLastName + " it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }
}

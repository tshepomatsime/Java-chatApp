import java.util.Scanner;

public class friday
{
       
    public static void main(String[] args)
    {
        Scanner input= new Scanner (System.in);
        
        int value1 , value2 , value3;
        
        System.out.println("Enter value1");
        value1=input.nextInt();
        System.out.print("Enter value2");
        value2=input.nextInt();
        System.out.println("Enter value3");
        value3=input.nextInt();
        
    if (value1>value2 && value1>value3)
    {
        System.out.println(value1+ "is greater");
    }    
    else if (value2>value1 && value2>value3)
    {
        System.out.println( value2 +" is greater");
    }    
    else
    {
        System.out.println(value3 +" is greater.");
    }
    } 
    
}

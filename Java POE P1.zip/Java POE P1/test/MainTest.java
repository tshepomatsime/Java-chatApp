import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MainTest {

    private Login login;

    @BeforeEach
    public void setUp() {
        login = new Login();
    }

    // ==========================================
    // USERNAME TESTS
    // ==========================================

    @Test
    public void testCheckUserName_ValidFormat() {
        // Contains '_' and length <= 5
        assertTrue(login.checkUserName("kyl_1"));
    }

    @Test
    public void testCheckUserName_InvalidFormat_NoUnderscore() {
        assertFalse(login.checkUserName("kyl12"));
    }

    @Test
    public void testCheckUserName_InvalidFormat_TooLong() {
        // Contains '_' but length > 5
        assertFalse(login.checkUserName("kyle_123"));
    }

    // ==========================================
    // PASSWORD TESTS
    // ==========================================

    @Test
    public void testCheckPasswordComplexity_Valid() {
        // >= 8 chars, 1 uppercase, 1 digit, 1 special character
        assertTrue(login.checkPasswordComplexity("Ch3&sec@ke"));
    }

    @Test
    public void testCheckPasswordComplexity_Invalid_NoSpecialChar() {
        assertFalse(login.checkPasswordComplexity("Password123"));
    }

    @Test
    public void testCheckPasswordComplexity_Invalid_TooShort() {
        assertFalse(login.checkPasswordComplexity("P1@ss"));
    }

    // ==========================================
    // CELL PHONE TESTS
    // ==========================================

    @Test
    public void testCheckCellPhoneNumber_Valid() {
        assertTrue(login.checkCellPhoneNumber("+27838968976"));
    }

    @Test
    public void testCheckCellPhoneNumber_Invalid_NoCountryCode() {
        assertFalse(login.checkCellPhoneNumber("0838968976"));
    }

    // ==========================================
    // REGISTRATION TESTS
    // ==========================================

    @Test
    public void testRegisterUser_Success() {
        String result = login.registerUser("kyl_1", "Ch3&sec@ke", "+27838968976", "Kyle", "Smith");
        String expected = "Username successfully captured.\nPassword successfully captured.\nCell number successfully added.";
        assertEquals(expected, result);
    }

    @Test
    public void testRegisterUser_FailedUsername() {
        String result = login.registerUser("kyle_smith", "Ch3&sec@ke", "+27838968976", "Kyle", "Smith");
        assertTrue(result.startsWith("Username is not correctly formatted"));
    }

    // ==========================================
    // LOGIN TESTS
    // ==========================================

    @Test
    public void testLoginUser_Success() {
        login.registerUser("kyl_1", "Ch3&sec@ke", "+27838968976", "Kyle", "Smith");
        assertTrue(login.loginUser("kyl_1", "Ch3&sec@ke"));
    }

    @Test
    public void testLoginUser_Failure() {
        login.registerUser("kyl_1", "Ch3&sec@ke", "+27838968976", "Kyle", "Smith");
        assertFalse(login.loginUser("kyl_1", "WrongPassword"));
    }

    @Test
    public void testReturnLoginStatus_SuccessMessage() {
        login.registerUser("kyl_1", "Ch3&sec@ke", "+27838968976", "Kyle", "Smith");
        boolean isLoggedIn = login.loginUser("kyl_1", "Ch3&sec@ke");
        
        String actual = login.returnLoginStatus(isLoggedIn);
        String expected = "Welcome Kyle, Smith it is great to see you again.";
        
        assertEquals(expected, actual);
    }

    @Test
    public void testReturnLoginStatus_FailureMessage() {
        String actual = login.returnLoginStatus(false);
        String expected = "Username or password incorrect, please try again.";
        
        assertEquals(expected, actual);
    }
}
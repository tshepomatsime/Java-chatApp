package chatapp;

import java.util.Scanner;
import java.util.regex.Pattern;
import java.util.Random;
import java.util.ArrayList;
import java.io.FileWriter;
import java.io.IOException;

public class main {

    // =========================================================
    // ============== CUSTOM UNIT TEST FRAMEWORK ===============
    // =========================================================
    static int testsPassed = 0;
    static int testsFailed = 0;

    static void assertEquals(Object expected, Object actual, String testName) {
        if (expected.equals(actual)) {
            System.out.println("[PASS] " + testName);
            testsPassed++;
        } else {
            System.out.println("[FAIL] " + testName);
            System.out.println("       Expected: " + expected);
            System.out.println("       Actual:   " + actual);
            testsFailed++;
        }
    }

    static void assertTrue(boolean condition, String testName) {
        assertEquals(true, condition, testName);
    }

    static void assertFalse(boolean condition, String testName) {
        assertEquals(false, condition, testName);
    }

    // =========================================================
    // ======================= MAIN METHOD =====================
    // =========================================================
    public static void main(String[] args) {

        // STEP 1: RUN UNIT TESTS
        System.out.println("=========================================");
        System.out.println("        RUNNING UNIT TESTS               ");
        System.out.println("=========================================\n");
        runUnitTests();
        System.out.println("\nTests Passed: " + testsPassed + " | Tests Failed: " + testsFailed + "\n");

        // STEP 2: INTERACTIVE REGISTRATION
        Scanner scanner = new Scanner(System.in);
        Login login = new Login();

        System.out.println("=========================================");
        System.out.println("        REGISTRATION SYSTEM              ");
        System.out.println("=========================================\n");

        System.out.print("Enter First Name: ");
        String firstName = scanner.nextLine();
        System.out.print("Enter Last Name: ");
        String lastName = scanner.nextLine();
        System.out.print("Enter Username (must contain '_' and be <= 5 chars): ");
        String username = scanner.nextLine();
        System.out.print("Enter Password (min 8 chars, 1 capital, 1 number, 1 special): ");
        String password = scanner.nextLine();
        System.out.print("Enter Cell Phone (e.g. +27838968976): ");
        String cellPhone = scanner.nextLine();

        String registrationMessage = login.registerUser(username, password, cellPhone, firstName, lastName);
        System.out.println("\n--- Registration Result ---");
        System.out.println(registrationMessage);

        // STEP 3: INTERACTIVE LOGIN
        if (registrationMessage.startsWith("Username successfully")) {
            System.out.println("\n=========================================");
            System.out.println("              LOGIN                      ");
            System.out.println("=========================================\n");

            boolean isLoggedIn = false;
            int attempts = 0;

            while (attempts < 3) {
                System.out.print("Enter Username: ");
                String loginUsername = scanner.nextLine();
                System.out.print("Enter Password: ");
                String loginPassword = scanner.nextLine();

                isLoggedIn = login.loginUser(loginUsername, loginPassword);
                System.out.println("\n--- Login Result ---");
                System.out.println(login.returnLoginStatus(isLoggedIn));
                System.out.println();

                if (isLoggedIn) break;
                attempts++;
                if (attempts < 3) System.out.println("Try again. Attempts remaining: " + (3 - attempts));
            }

            // STEP 4: QUICKCHAT APPLICATION
            if (isLoggedIn) {
                System.out.println("\nWelcome to QuickChat.");
                Message messageApp = new Message();
               
                System.out.print("How many messages do you wish to enter? ");
                int numMessages = 0;
                try {
                    numMessages = Integer.parseInt(scanner.nextLine());
                } catch (NumberFormatException e) {
                    System.out.println("Invalid number entered. Exiting.");
                    return;
                }

                int messagesEntered = 0;
                boolean running = true;

                while (running) {
                    System.out.println("\n--- QuickChat Menu ---");
                    System.out.println("1) Send Messages");
                    System.out.println("2) Show recently sent messages");
                    System.out.println("3) Quit");
                    System.out.print("Choose an option: ");
                    String choice = scanner.nextLine();

                    switch (choice) {
                        case "1":
                            if (messagesEntered >= numMessages) {
                                System.out.println("You have reached your message limit.");
                                break;
                            }
                           
                            System.out.print("Enter Recipient Cell Number: ");
                            String recipient = scanner.nextLine();
                           
                            System.out.print("Enter Message (max 250 chars): ");
                            String msgText = scanner.nextLine();

                            Message newMsg = new Message();
                            newMsg.recipient = recipient;
                            newMsg.messageText = msgText;
                            newMsg.messageNumber = messageApp.returnTotalMessages() + 1;

                            String result = newMsg.SentMessage(scanner);
                            System.out.println(result);
                           
                            if (result.equals("Message successfully sent") || result.equals("Message successfully stored")) {
                                messageApp.addMessage(newMsg);
                                messagesEntered++;
                            }
                            break;

                        case "2":
                            System.out.println("Coming Soon.");
                            break;

                        case "3":
                            running = false;
                            System.out.println("Exiting QuickChat...");
                            System.out.println("Total messages processed: " + messageApp.returnTotalMessages());
                            break;

                        default:
                            System.out.println("Invalid option. Please choose 1, 2, or 3.");
                    }
                }
            }
        } else {
            System.out.println("\nRegistration failed. Cannot proceed.");
        }

        scanner.close();
    }

    // =========================================================
    // ==================== UNIT TEST SUITE ====================
    // =========================================================
    static void runUnitTests() {
        System.out.println("--- Message Length Tests ---");
        Message msg = new Message();
       
        // Test: Message <= 250 chars
        msg.messageText = "Hi Mike, can you join us for dinner tonight?";
        assertEquals("Message ready to send.", msg.checkMessageLength(), "Message is 250 characters or less");

        // Test: Message > 250 chars
        msg.messageText = "A".repeat(260);
        assertEquals("Message exceeds 250 characters by 10; please reduce the size.", msg.checkMessageLength(), "Message exceeds 250 characters");

        System.out.println("\n--- Recipient Cell Tests ---");
        // Test: Correct formatting
        msg.recipient = "+27718693002";
        assertEquals("Cell phone number successfully captured.", msg.checkRecipientCell(), "Cell phone correctly formatted");

        // Test: Incorrect formatting
        msg.recipient = "08575975889";
        assertEquals("Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.", msg.checkRecipientCell(), "Cell phone incorrectly formatted");

        System.out.println("\n--- Message Hash Tests ---");
        String hashResult = msg.createMessageHashForTest("0012345678", 0, "Hi Mike, can you join us for dinner tonight?");
        assertEquals("00:0:HITONIGHT", hashResult, "Message Hash correctly generated");

        System.out.println("\n--- Message ID Tests ---");
        Message idMsg = new Message();
        assertTrue(idMsg.checkMessageID(), "Message ID is created and <= 10 chars");

        System.out.println("\n--- Message Sent Actions Tests ---");
        Message actionMsg = new Message();
        actionMsg.recipient = "+27718693002";
        actionMsg.messageText = "Test message";
       
        Scanner mockScanner1 = new Scanner("1\n");
        assertEquals("Message successfully sent", actionMsg.SentMessage(mockScanner1), "User selected 'Send Message'");

        Scanner mockScanner2 = new Scanner("2\n");
        assertEquals("Press 0 to delete the message.", actionMsg.SentMessage(mockScanner2), "User selected 'Disregard Message'");

        Scanner mockScanner3 = new Scanner("3\n");
        assertEquals("Message successfully stored", actionMsg.SentMessage(mockScanner3), "User selected 'Store Message'");
    }
}

// =========================================================
// ====================== LOGIN CLASS ======================
// =========================================================
class Login {
    private String storedUsername, storedPassword, storedCellPhone, storedFirstName, storedLastName;

    public boolean checkUserName(String username) {
        return username != null && username.contains("_") && username.length() <= 5;
    }

    public boolean checkPasswordComplexity(String password) {
        if (password == null) return false;
        return Pattern.matches("^(?=.*[A-Z])(?=.*\\d)(?=.*[^a-zA-Z0-9]).{8,}$", password);
    }

    public boolean checkCellPhoneNumber(String phone) {
        if (phone == null) return false;
        return Pattern.matches("^\\+27[0-9]{7,9}$", phone);
    }

    public String registerUser(String username, String password, String cellPhone, String firstName, String lastName) {
        if (!checkUserName(username)) return "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.";
        if (!checkPasswordComplexity(password)) return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        if (!checkCellPhoneNumber(cellPhone)) return "Cell number is incorrectly formatted or does not contain an international code; please correct the number and try again.";

        this.storedUsername = username; this.storedPassword = password; this.storedCellPhone = cellPhone;
        this.storedFirstName = firstName; this.storedLastName = lastName;
        return "Username successfully captured.\nPassword successfully captured.\nCell number successfully added.";
    }

    public boolean loginUser(String username, String password) {
        return username != null && password != null && username.equals(this.storedUsername) && password.equals(this.storedPassword);
    }

    public String returnLoginStatus(boolean isLoggedIn) {
        if (isLoggedIn) return "Welcome " + this.storedFirstName + ", " + this.storedLastName + " it is great to see you again.";
        return "Username or password incorrect, please try again.";
    }
}

// =========================================================
// ===================== MESSAGE CLASS =====================
// =========================================================
class Message {
    public String messageId;
    public int messageNumber;
    public String recipient;
    public String messageText;
    public String messageHash;
   
    private static ArrayList<Message> allMessages = new ArrayList<>();

    public Message() {
        Random rand = new Random();
        long id = (long) (rand.nextDouble() * 9_000_000_000L) + 1_000_000_000L;
        this.messageId = String.valueOf(id);
    }

    public void addMessage(Message msg) {
        allMessages.add(msg);
    }

    // *** FIXED: Added this method back so the main code compiles ***
    public int returnTotalMessages() {
        return allMessages.size();
    }

    public boolean checkMessageID() {
        return messageId != null && messageId.length() <= 10;
    }

    public String checkMessageLength() {
        if (messageText.length() > 250) {
            int excess = messageText.length() - 250;
            return "Message exceeds 250 characters by " + excess + "; please reduce the size.";
        }
        return "Message ready to send.";
    }

    public String checkRecipientCell() {
        if (recipient != null && Pattern.matches("^\\+27[0-9]{7,9}$", recipient)) {
            return "Cell phone number successfully captured.";
        }
        return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
    }

    public String createMessageHash() {
        return createMessageHashForTest(this.messageId, this.messageNumber, this.messageText);
    }

    public String createMessageHashForTest(String id, int msgNum, String text) {
        if (text == null || text.trim().isEmpty()) return "";
       
        String firstTwoId = id.length() >= 2 ? id.substring(0, 2) : id;
       
        String[] words = text.trim().split("\\s+");
        String firstWord = words[0].replaceAll("[^a-zA-Z]", "");
        String lastWord = words[words.length - 1].replaceAll("[^a-zA-Z]", "");
       
        if (words.length == 1) {
            return (firstTwoId + ":" + msgNum + ":" + firstWord).toUpperCase();
        }
       
        return (firstTwoId + ":" + msgNum + ":" + firstWord + lastWord).toUpperCase();
    }

    public String SentMessage(Scanner scanner) {
        if (!checkMessageID()) return "Message ID invalid.";
       
        String cellCheck = checkRecipientCell();
        if (!cellCheck.equals("Cell phone number successfully captured.")) {
            return cellCheck;
        }
       
        String lengthCheck = checkMessageLength();
        if (!lengthCheck.equals("Message ready to send.")) {
            return lengthCheck;
        }

        this.messageHash = createMessageHash();

        System.out.println("\nChoose action:");
        System.out.println("1 - Send Message");
        System.out.println("2 - Disregard Message");
        System.out.println("3 - Store Message to send later");
        System.out.print("Choice: ");
        String choice = scanner.nextLine();

        switch (choice) {
            case "1":
                return "Message successfully sent";
            case "2":
                return "Press 0 to delete the message.";
            case "3":
                storeMessage();
                return "Message successfully stored";
            default:
                return "Invalid action. Message discarded.";
        }
    }

    public void storeMessage() {
        try {
            FileWriter file = new FileWriter("messages.json", true);
            String json = String.format(
                "{\n  \"id\": \"%s\",\n  \"hash\": \"%s\",\n  \"recipient\": \"%s\",\n  \"message\": \"%s\"\n},\n",
                messageId, messageHash, recipient, messageText
            );
            file.write(json);
            file.close();
        } catch (IOException e) {
            // Ignored for online compiler compatibility
        }
    }
}